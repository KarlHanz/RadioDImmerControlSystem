﻿namespace ZiLib.FileVersion.Common
{

    public enum FontOrientation : byte
    {
        Vertical = 0x0a,
        Horizontal = 0x0b,
        VerticalRotated = 0x0c,
        HorizontalRotated = 0x0d
    }

}